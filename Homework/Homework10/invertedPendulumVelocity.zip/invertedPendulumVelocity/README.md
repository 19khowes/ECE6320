**Running the simulator**

Open testSegwayPlot.m in Matlab

Run testSegwayPlot.m

Choose "Change Folder" and not "Add to Path" when Matlab presents the choice.